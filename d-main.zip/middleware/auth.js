const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Lets you grant admin access just by listing an email in the environment
// (comma-separated ADMIN_EMAILS) instead of needing direct DB access —
// handy for standing up the very first admin account.
const ADMIN_EMAILS = (process.env.ADMIN_EMAILS || '')
  .split(',')
  .map((e) => e.trim().toLowerCase())
  .filter(Boolean);

async function maybeAutoPromoteAdmin(user) {
  if (!user || user.is_admin) return user;
  if (ADMIN_EMAILS.includes((user.email || '').toLowerCase())) {
    await User.setAdmin(user.id, true);
    user.is_admin = 1;
  }
  return user;
}

async function requireAuth(req, res, next) {
  const token = req.cookies.token;
  if (!token) {
    req.flash('error', 'Please log in to continue.');
    return res.redirect('/login');
  }
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    let user = await User.findById(payload.id);
    if (!user) {
      res.clearCookie('token');
      req.flash('error', 'Session expired. Please log in again.');
      return res.redirect('/login');
    }
    if (user.is_banned) {
      res.clearCookie('token');
      req.flash('error', user.ban_reason ? `Your account has been suspended: ${user.ban_reason}` : 'Your account has been suspended.');
      return res.redirect('/login');
    }
    user = await maybeAutoPromoteAdmin(user);
    req.user = user;
    res.locals.user = user;
    next();
  } catch (err) {
    res.clearCookie('token');
    req.flash('error', 'Session expired. Please log in again.');
    return res.redirect('/login');
  }
}

// Attaches req.user if logged in, but does not block the route
async function attachUser(req, res, next) {
  const token = req.cookies.token;
  if (!token) return next();
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    let user = await User.findById(payload.id);
    if (user && user.is_banned) {
      // A banned user's cookie is still technically valid, but they should
      // otherwise look logged out — log them out quietly rather than
      // blocking every public page with a flash message.
      res.clearCookie('token');
      return next();
    }
    if (user) {
      user = await maybeAutoPromoteAdmin(user);
      req.user = user;
      res.locals.user = user;
    }
  } catch (err) {
    // ignore invalid token
  }
  next();
}

module.exports = { requireAuth, attachUser };
