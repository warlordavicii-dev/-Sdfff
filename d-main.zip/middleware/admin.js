// Assumes requireAuth has already run (req.user is set) — only checks the
// admin flag on top of that.
function requireAdmin(req, res, next) {
  if (!req.user) {
    req.flash('error', 'Please log in to continue.');
    return res.redirect('/login');
  }
  if (!req.user.is_admin) {
    req.flash('error', "You don't have access to that page.");
    return res.redirect('/dashboard');
  }
  next();
}

module.exports = { requireAdmin };
