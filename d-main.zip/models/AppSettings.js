const pool = require('../config/db');

const DEFAULTS = {
  daily_coins_amount: '5',
  referral_bonus_amount: '10'
};

const AppSettings = {
  async get(key, fallback) {
    const [rows] = await pool.query('SELECT value FROM app_settings WHERE `key` = ? LIMIT 1', [key]);
    if (rows[0]) return rows[0].value;
    if (fallback !== undefined) return fallback;
    return DEFAULTS[key] !== undefined ? DEFAULTS[key] : null;
  },

  async getInt(key, fallback) {
    const value = await this.get(key, fallback);
    const parsed = parseInt(value, 10);
    return Number.isFinite(parsed) ? parsed : fallback;
  },

  async set(key, value) {
    await pool.query(
      `INSERT INTO app_settings (\`key\`, value) VALUES (?, ?)
       ON DUPLICATE KEY UPDATE value = VALUES(value)`,
      [key, String(value)]
    );
  },

  // Convenience for the admin panel — returns the small set of coin-economy
  // knobs as numbers, falling back to sane defaults if never configured.
  async getCoinSettings() {
    const [dailyCoinsAmount, referralBonusAmount] = await Promise.all([
      this.getInt('daily_coins_amount', 5),
      this.getInt('referral_bonus_amount', 10)
    ]);
    return { dailyCoinsAmount, referralBonusAmount };
  }
};

module.exports = AppSettings;
