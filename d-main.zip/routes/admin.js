const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const fs = require('fs');
const path = require('path');

const User = require('../models/User');
const AppSettings = require('../models/AppSettings');
const CoinTransaction = require('../models/CoinTransaction');
const { requireAuth } = require('../middleware/auth');
const { requireAdmin } = require('../middleware/admin');
const { sendCoinsReceivedEmail } = require('../utils/mailer');

const PAGE_SIZE = 20;

router.use(requireAuth, requireAdmin);

function isLocalAvatarPath(url) {
  return typeof url === 'string' && url.startsWith('/uploads/avatars/');
}

function deleteLocalAvatar(url) {
  if (!isLocalAvatarPath(url)) return;
  const filePath = path.join(__dirname, '..', 'public', url);
  fs.unlink(filePath, (err) => {
    if (err && err.code !== 'ENOENT') console.error('Failed to delete avatar:', err.message);
  });
}

// -----------------------------------------------------
// DASHBOARD
// -----------------------------------------------------

router.get('/admin', async (req, res) => {
  const search = (req.query.q || '').trim();
  const page = Math.max(1, parseInt(req.query.page, 10) || 1);
  const offset = (page - 1) * PAGE_SIZE;

  try {
    const [users, totalUsers, coinSettings] = await Promise.all([
      User.listUsers({ search, limit: PAGE_SIZE, offset }),
      User.countUsers({ search }),
      AppSettings.getCoinSettings()
    ]);

    res.render('admin', {
      title: 'Admin panel',
      users,
      search,
      page,
      totalPages: Math.max(1, Math.ceil(totalUsers / PAGE_SIZE)),
      totalUsers,
      coinSettings
    });
  } catch (err) {
    console.error('Admin dashboard failed to load:', err.message);
    req.flash('error', 'Could not load the admin panel.');
    res.redirect('/dashboard');
  }
});

// -----------------------------------------------------
// COIN ECONOMY SETTINGS
// -----------------------------------------------------

router.post(
  '/admin/settings',
  [
    body('dailyCoinsAmount').isInt({ min: 0, max: 100000 }).withMessage('Daily coins amount must be a whole number.'),
    body('referralBonusAmount').isInt({ min: 0, max: 100000 }).withMessage('Referral bonus must be a whole number.')
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      req.flash('error', errors.array()[0].msg);
      return res.redirect('/admin');
    }

    try {
      await Promise.all([
        AppSettings.set('daily_coins_amount', parseInt(req.body.dailyCoinsAmount, 10)),
        AppSettings.set('referral_bonus_amount', parseInt(req.body.referralBonusAmount, 10))
      ]);
      req.flash('success', 'Coin economy settings updated.');
    } catch (err) {
      console.error('Updating coin settings failed:', err.message);
      req.flash('error', 'Could not update settings.');
    }
    res.redirect('/admin');
  }
);

// -----------------------------------------------------
// GRANT COINS (unlimited — admin mints, doesn't spend their own balance)
// -----------------------------------------------------

router.post(
  '/admin/grant-coins',
  [
    body('email').trim().isEmail().withMessage('Enter a valid member email.').normalizeEmail(),
    body('amount').isInt({ min: 1, max: 1000000 }).withMessage('Enter a whole number of coins to grant.')
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      req.flash('error', errors.array()[0].msg);
      return res.redirect('/admin');
    }

    const amount = parseInt(req.body.amount, 10);

    try {
      const recipient = await User.findByEmail(req.body.email);
      if (!recipient) {
        req.flash('error', 'No account found with that email.');
        return res.redirect('/admin');
      }

      await User.grantCoins(recipient.id, amount);
      await CoinTransaction.log({
        userId: recipient.id,
        type: 'admin_grant',
        amount,
        note: `Granted by admin ${req.user.email}`
      });

      sendCoinsReceivedEmail(recipient.email, {
        fromName: `${process.env.APP_NAME || 'The team'} (admin)`,
        amount
      }).catch((err) => console.error('Admin grant notification email failed:', err.message));

      req.flash('success', `Granted ${amount} coins to ${recipient.username}.`);
    } catch (err) {
      console.error('Admin coin grant failed:', err.message);
      req.flash('error', 'Could not grant coins.');
    }
    res.redirect('/admin');
  }
);

// -----------------------------------------------------
// BAN / UNBAN
// -----------------------------------------------------

router.post('/admin/users/:id/ban', async (req, res) => {
  const targetId = parseInt(req.params.id, 10);

  if (targetId === req.user.id) {
    req.flash('error', "You can't ban your own account.");
    return res.redirect('/admin');
  }

  try {
    const target = await User.findById(targetId);
    if (!target) {
      req.flash('error', 'User not found.');
      return res.redirect('/admin');
    }
    if (target.is_admin) {
      req.flash('error', "You can't ban another admin. Remove their admin access first.");
      return res.redirect('/admin');
    }

    await User.banUser(targetId, (req.body.reason || '').trim() || null);
    req.flash('success', `${target.username} has been banned.`);
  } catch (err) {
    console.error('Ban failed:', err.message);
    req.flash('error', 'Could not ban that user.');
  }
  res.redirect('/admin');
});

router.post('/admin/users/:id/unban', async (req, res) => {
  const targetId = parseInt(req.params.id, 10);
  try {
    await User.unbanUser(targetId);
    req.flash('success', 'User has been unbanned.');
  } catch (err) {
    console.error('Unban failed:', err.message);
    req.flash('error', 'Could not unban that user.');
  }
  res.redirect('/admin');
});

// -----------------------------------------------------
// DELETE USER
// -----------------------------------------------------

router.post('/admin/users/:id/delete', async (req, res) => {
  const targetId = parseInt(req.params.id, 10);

  if (targetId === req.user.id) {
    req.flash('error', 'Use your own account settings to delete your account.');
    return res.redirect('/admin');
  }

  try {
    const target = await User.findById(targetId);
    if (!target) {
      req.flash('error', 'User not found.');
      return res.redirect('/admin');
    }
    if (target.is_admin) {
      req.flash('error', "You can't delete another admin. Remove their admin access first.");
      return res.redirect('/admin');
    }

    await User.deleteAccount(targetId);
    deleteLocalAvatar(target.avatar_url);
    req.flash('success', `${target.username}'s account has been deleted.`);
  } catch (err) {
    console.error('Admin delete failed:', err.message);
    req.flash('error', 'Could not delete that user.');
  }
  res.redirect('/admin');
});

module.exports = router;
